import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pizza',
  templateUrl: './pizza.component.html',
  styleUrls: ['./pizza.component.scss']
})
export class PizzaComponent implements OnInit {

 public products:Array<any>=[];
 public view:boolean=false;

 public viewdata:any;

  constructor() {
    this.products = [
      {
      sno: "1",
      customerName: 'Arun',
      noofOrder: "1",
      totalAmount: "100",
      price: "100",
      itemName:'Veg Pizza',
      status : 'Order Received',
      address : 'No.1, First Street, Chennai'
    },
    {
      sno: "2",
      customerName: 'Bala',
      noofOrder: "2",
      price: "200",
      totalAmount : "400",
      itemName:'Cheese Pizza',
      status : 'Preparing',
      address : 'No.2, Second Street, Chennai'
    },
    {
      sno: "3",
      customerName: 'Chitra',
      noofOrder: "2",
      price: "250",
      totalAmount : "500",
      itemName:'Chicken Pizza',
      status : 'Ready To Serve',
      address : 'No.3, Third Street, Chennai'
    },
    {
      sno: "4",
      customerName: 'Dani',
      noofOrder: "3",
      price: "300",
      totalAmount : "900",
      itemName:'Mushroom Pizza',
      status : 'Preparing',
      address : 'No.4, Fourth Street, Chennai'
    },
    {
      sno: "5",
      customerName: 'Eliza',
      noofOrder: "1",
      price: "150",
      totalAmount : "150",
      itemName:'Egg Pizza',
      status : 'Ready To Serve',
      address : 'No.5, Fifth Street, Chennai'
    },
  ];
   
   }

  ngOnInit(): void {
  }
/*Author        : Banupriyanka S
  Function Name : goView
  Description   : To display the order details while clicking view button*/

  public goView(id:number,show:string,status:string){
    this.viewdata=this.products[id-1];    
    if(show==='view'){
      this.view=true;
    }
  }

/*Author        : Banupriyanka S
  Function Name : goView
  Description   : To display the list again while clicking back button*/

  public goback():void{
    this.view=false;
  }

  /*Author        : Banupriyanka S
  Function Name : onChange
  Description   : To edit the order status while on change*/

  public onChange(id:number,status:string){

    /*To Edit the order status*/

    this.viewdata = this.products[id-1];
     if(status != ''){
      this.viewdata.status = status;
      this.products[id-1] = this.viewdata;
    }
  }
}
